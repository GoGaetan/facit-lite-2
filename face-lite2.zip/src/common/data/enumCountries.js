const COUNTRIES = {
	IVORY_COAST: {
		name: 'Ivory Coast',
	},
	CAMEROON: {
		name: 'Cameroon',
	},
	SENEGAL: {
		name: 'Senegal',
	},
	MALI: {
		name: 'Mali',
	},
	BURKINA_FASO: {
		name: 'Burkina Faso',
	},
	GUINNEA: {
		name: 'Guinnea',
	},
};

export default COUNTRIES;
